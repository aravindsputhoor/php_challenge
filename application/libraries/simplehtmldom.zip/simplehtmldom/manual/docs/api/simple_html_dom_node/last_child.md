# last_child

```php
last_child ( ) : object
```

Returns the last child of the current node or null if the current node has no child elements.